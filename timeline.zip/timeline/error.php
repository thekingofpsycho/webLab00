<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Simple Timeline</title>
        <link rel="stylesheet" href="timeline.css">
    </head>
    <body>
        <div>
            <a href="index.php"><h1>Simple Timeline - ERROR</h1></a>
            <p>
                <a href="index.php">Try Again?</a>
            </p>
        </div>
    </body>
</html>
